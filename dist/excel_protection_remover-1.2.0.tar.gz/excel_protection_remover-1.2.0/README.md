![version](https://img.shields.io/badge/version-0.1-blue.svg)
![date](https://img.shields.io/badge/date-20.10.2025-green.svg)
![status](https://img.shields.io/badge/status-development-yellow.svg)
![license](https://img.shields.io/badge/license-MIT-lightgrey.svg)

# Remove Excel Protection

Python Projekt, um den Blattschutz aufzuheben, sofern das PW vergessen wurde.

- Keyfeature 1: Kurze Beschreibung
- Keyfeature 2: Kurze Beschreibung

***
## Content

1. [Getting Started](#getting-started)
11. [Lizenz](#lizenz)
12. [Versionshistorie](#versionshistorie)

***
## Getting Started

t.b.d



***
## Lizenz

Dieses Projekt steht unter der [MIT License](LICENSE).

***
## Versionshistorie

| Datum / Version   | Autor         | Bemerkung                               |
|-------------------|---------------|-----------------------------------------|
| 20.10.2025 / v0.1 | Tim Häberlein | Grundlegende Erstellung                 |
|                   |               |                                         |
|                   |               |                                         |