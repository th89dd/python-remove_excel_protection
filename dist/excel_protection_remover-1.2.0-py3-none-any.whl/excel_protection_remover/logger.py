# -*- coding: utf-8 -*-
"""
:author: Tim Häberlein
:version: 1.0
:date: 20.10.2025
:organisation: TU Dresden, FZM
"""

# -------- start import block ---------
import logging
import os
from typing import Optional
# -------- /import block ---------

class LoggerFactory:
    """Zentrale Logging-Fabrik für das gesamte Package.

    Diese Klasse verwaltet das globale Logging-Setup für alle Komponenten.
    Sie sorgt dafür, dass:
      * das Logging-System nur einmal konfiguriert wird (Singleton-Pattern),
      * alle Logger einheitliche Formatierung und Handler nutzen,
      * optionale Datei-Logs unterstützt werden,
      * und das Log-Level zentral steuerbar ist.

    Beispiel:
        >>> LoggerFactory.configure(level="DEBUG", logfile="log.txt")
        >>> logger = LoggerFactory.get_logger("excel_protection_remover.cleaner")
        >>> logger.info("Cleaner gestartet")
    """

    __is_configured = False
    __default_level = logging.INFO
    __logfile_path: Optional[str] = None

    @classmethod
    def configure(cls, level: str = "INFO", logfile: Optional[str] = None, fmt: Optional[str] = None,) -> None:
        """Initialisiert das globale Logging-System.

        Args:
            level: Log-Level-Name (z. B. "DEBUG", "INFO", "WARNING", "ERROR").
            logfile: Optionaler Pfad für Logdatei (wenn None → keine Datei).
            fmt: Optionales Format-Template für Logzeilen.
        """
        if cls.__is_configured:
            return

        cls.__default_level = getattr(logging, level.upper(), logging.INFO)
        cls.__logfile_path = logfile

        log_format = fmt or "[%(asctime)s] [%(levelname)s] %(name)s: %(message)s"
        datefmt = "%Y-%m-%d %H:%M:%S"

        root_logger = logging.getLogger()
        root_logger.setLevel(cls.__default_level)

        # Konsole
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(logging.Formatter(log_format, datefmt))
        root_logger.addHandler(console_handler)

        # Datei (optional)
        if logfile:
            logfile = os.path.abspath(logfile)
            file_handler = logging.FileHandler(logfile, encoding="utf-8")
            file_handler.setFormatter(logging.Formatter(log_format, datefmt))
            root_logger.addHandler(file_handler)
            root_logger.info(f"Logging in Datei: {logfile}")

        cls.__is_configured = True
        root_logger.debug("LoggerFactory erfolgreich konfiguriert.")

    @classmethod
    def get_logger(cls, name: Optional[str] = None) -> logging.Logger:
        """Gibt einen hierarchischen Logger zurück.

        Args:
            name: Optionaler Loggername (z. B. Modulname oder Klassenname).
                Wenn None, wird der Standardname "excel_protection_remover" verwendet.

        Returns:
            logging.Logger: Konfigurierter Logger.
        """
        if not cls.__is_configured:
            cls.configure()
        if not name:
            name = "excel_protection_remover"
        return logging.getLogger(name)

    @classmethod
    def set_level(cls, level: str) -> None:
        """Ändert den globalen Log-Level zur Laufzeit.

        Args:
            level: Log-Level-Name ("DEBUG", "INFO", etc.).
        """
        lvl = getattr(logging, level.upper(), logging.INFO)
        logging.getLogger().setLevel(lvl)
        cls.__default_level = lvl


# ausführung nur bei direktem Script-Aufruf
if __name__ == '__main__':
    print('run')
    pass
